 
#pragma warning( disable : 4996 ) 
 
#include <cstdlib>
#include <vector>
#include <iostream>
#include <string>
#include "G2D.h"
 

using namespace std;
  
 

struct GameData
{
	int HeighPix = 800;   // hauteur de la fen�tre d'application
	int WidthPix = 600;   // largeur de la fen�tre d'application
     
	GameData() {}
};

GameData G;


void Render()
{
	G2D::ClearScreen(Color::Black);
 
	G2D::DrawStringFontMono(V2(50, 100), "Hello World !", 20, 3, Color::Red);
	   
	G2D::Show();
}

 
void Logic()
{
	 
}
 
// Load texture at startup
void AssetsInit()
{
	 
}

int main(int argc, char* argv[])
{ 
	// create windows
	G2D::InitWindow(argc,argv,V2(320,200), V2(20,20), string("Test"));
	  
	// load assets
	AssetsInit();
	  
	// run game
	G2D::Run(Logic,Render);
 
}
 
  
 